package tech.stackable.nifi.processors.sample;

import org.apache.nifi.util.TestRunner;
import org.apache.nifi.util.TestRunners;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ShoutProcessorTest {

    private TestRunner testRunner;

    @BeforeEach
    public void init() {
        testRunner = TestRunners.newTestRunner(ShoutProcessor.class);
    }

    @Test
    public void testProcessor() {
        testRunner.enqueue("Hello, world!");

        testRunner.run();

        testRunner.assertTransferCount(ShoutProcessor.REL_SUCCESS, 1);
        var flowFile = testRunner.getFlowFilesForRelationship(ShoutProcessor.REL_SUCCESS).get(0);
        flowFile.assertContentEquals("HELLO, WORLD!");
    }
}
