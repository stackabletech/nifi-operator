package tech.stackable.nifi.processors.sample;

import org.apache.nifi.annotation.documentation.CapabilityDescription;
import org.apache.nifi.flowfile.FlowFile;
import org.apache.nifi.processor.*;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Set;

@CapabilityDescription("A Java processor that shouts the received.")
public class ShoutProcessor extends AbstractProcessor {

    public static final Relationship REL_SUCCESS = new Relationship.Builder()
            .name("success")
            .description("Example success relationship")
            .build();

    private Set<Relationship> relationships;

    @Override
    protected void init(final ProcessorInitializationContext context) {
        relationships = Set.of(REL_SUCCESS);
    }

    @Override
    public Set<Relationship> getRelationships() {
        return this.relationships;
    }

    @Override
    public void onTrigger(final ProcessContext context, final ProcessSession session) {
        FlowFile flowFile = session.get();
        if (flowFile != null) {
            session.write(flowFile, (in, out) -> {
                try (var reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                     var writer = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8))) {

                    String line;
                    while ((line = reader.readLine()) != null) {
                        writer.write(line.toUpperCase(Locale.ROOT));
                    }
                }
            });
            session.transfer(flowFile, REL_SUCCESS);
        }
    }
}
